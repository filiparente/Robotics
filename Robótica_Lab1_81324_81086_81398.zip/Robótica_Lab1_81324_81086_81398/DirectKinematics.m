% Function for Direct Kinematics

function [x,y,z,alfa,beta,gama] = DirectKinematics(teta1, teta2, teta3, teta4, teta5, teta6)

% Control the value of teta1
if (  (teta1 >= -((3*pi)/4)) && ( teta1 <= pi/2) )
    
    % The value is good, construct link transformation for teta1
    Trx = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Ta = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta1) -sin(teta1) 0 0; sin(teta1) cos(teta1) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 99; 0 0 0 1];
    Trans_0_1 = Trx*Ta*Trz*Td;
else
   
   % The value is wrong!
   
   disp('ERROR: Teta1 must be bigger or equal than -((3*pi)/4) and smaller or equal than (pi/2). Must be in radians!');
   return;
end

% Control the value of teta2
if (  (teta2 >= -(1.4)) && (teta2 <= (1.19) ))
    
    % The value is good, construct link transformation for teta2
    Trx = [ 1 0 0 0; 0 0 1 0; 0 -1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 29; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta2-pi/2) -sin(teta2-pi/2) 0 0; sin(teta2-pi/2) cos(teta2-pi/2) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_1_2 = Trx*Ta*Trz*Td;
else
   
   % The value is wrong!
   disp('ERROR: Teta2 must be bigger or equal than -((4*pi)/9) and smaller or equal than (17*pi/45). Must be in radians!');
   return;
end

% Control the value of teta3
if ( teta2 >= 0)
    if ( (teta3 > (-teta2 + pi/2)) || (teta3 < (-teta2 - 2*pi/18) ))
        disp('ERROR: If teta2 is positive, teta3 must be smaller or equal than (-teta2 + pi/2) and bigger or equal than (-teta2 - 2*pi/18). Must be in radians!');
        return;
    else
        % The value is good, construct link transformation for teta3
        Trx = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
        Ta = [ 1 0 0 120; 0 1 0 0; 0 0 1 0; 0 0 0 1];
        Trz = [ cos(teta3) -sin(teta3) 0 0; sin(teta3) cos(teta3) 0 0; 0 0 1 0; 0 0 0 1];
        Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
        Trans_2_3 = Trx*Ta*Trz*Td;
    end
else
    if ( teta2 <= -pi/4 )
        if ( teta3 ~= -teta2-pi/18 )
            disp('ERROR: If teta2 is less than -pi/4, teta3 must be equal to (-teta2-pi/18). Must be in radians!');
            return;
        else
            % The value is good, construct link transformation for teta3
            Trx = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
            Ta = [ 1 0 0 120; 0 1 0 0; 0 0 1 0; 0 0 0 1];
            Trz = [ cos(teta3) -sin(teta3) 0 0; sin(teta3) cos(teta3) 0 0; 0 0 1 0; 0 0 0 1];
            Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
            Trans_2_3 = Trx*Ta*Trz*Td;
        end
    else
        if ( (teta3 > (-teta2 + 2*pi/18)) || (teta3 < (-teta2 - 2*pi/18)) )
            disp('ERROR: Teta3 must be bigger or equal than (-teta2 - 2*pi/18) and smaller or equal than (-teta2 + 2*pi/18). Must be in radians!');
            return;
        else
            % The value is good, construct link transformation for teta3
            Trx = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
            Ta = [ 1 0 0 120; 0 1 0 0; 0 0 1 0; 0 0 0 1];
            Trz = [ cos(teta3) -sin(teta3) 0 0; sin(teta3) cos(teta3) 0 0; 0 0 1 0; 0 0 0 1];
            Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
            Trans_2_3 = Trx*Ta*Trz*Td;
        end
    end
end

% Control the value of teta4
if (  (teta4 >= -((5*pi)/9)) && (teta4 <= ((5*pi)/9)) )
    
    % The value is good, construct link transformation for teta3
    Trx = [ 1 0 0 0; 0 0 1 0; 0 -1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 20; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta4) -sin(teta4) 0 0; sin(teta4) cos(teta4) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 140; 0 0 0 1];
    Trans_3_4 = Trx*Ta*Trz*Td;

else
    
   % The value is wrong!
   disp('ERROR: Teta4 must be bigger or equal than -(5*pi/9) and smaller or equal than (5*pi/9). Must be in radians!');
   return;
end

% Control the value of teta5
if (  (teta5 >= -(pi/2)) && (teta5 <= ((pi)/2)) )
    
    % The value is good, construct link transformation for teta3
    Trx = [ 1 0 0 0; 0 0 -1 0; 0 1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta5) -sin(teta5) 0 0; sin(teta5) cos(teta5) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_4_5 = Trx*Ta*Trz*Td;

else
    
   % The value is wrong!
   disp('ERROR: Teta5 must be bigger or equal than -(pi/2) and smaller or equal than (pi/2). Must be in radians!');
   return;
end

% Control the value of teta6
if (  (teta6 >= -(pi/2)) && (teta6 <= (pi/2)) )
    
    % The value is good, construct link transformation for teta3
    Trx = [ 1 0 0 0; 0 0 1 0; 0 -1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta6) -sin(teta6) 0 0; sin(teta6) cos(teta6) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_5_6 = Trx*Ta*Trz*Td;

else
   
   % The value is wrong!
   disp('ERROR: Teta6 must be bigger or equal than -(pi/2) and smaller or equal than (pi/2). Must be in radians!');
   return;
end

% Transformation link from referencial 0 to 6
T_0_6 = Trans_0_1*Trans_1_2*Trans_2_3*Trans_3_4*Trans_4_5*Trans_5_6;

% Point of end-efector at referencial 6
P6 = [0; 0; 22; 1];

% Point of end-efector at referencial 0
P0 = T_0_6*P6;
x = round(P0(1,1));
y = round(P0(2,1));
z = round(P0(3,1));

% Rotation matrix from referencial 0 to 6
R_0_6 = T_0_6(1:3 , 1:3);

% Orientation of end-efector
cos_beta = sqrt((R_0_6(1,1)^2)+(R_0_6(2,1)^2));

beta = atan2(-R_0_6(3,1) , cos_beta);
alfa = atan2( R_0_6(2,1)/cos_beta , R_0_6(1,1)/cos_beta);
gama = atan2( R_0_6(3,2)/cos_beta , R_0_6(3,3)/cos_beta);

end