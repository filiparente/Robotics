% Function for Inverse Kinematics

function [teta_f] = InverseKinematics(x,y,z,alfa,beta,gama)

% Find rotation matrixes for each coordenate
Rx = [1 0 0; 0 cos(gama) -sin(gama); 0 sin(gama) cos(gama)];
Ry = [cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Rz = [cos(alfa) -sin(alfa) 0; sin(alfa) cos(alfa) 0; 0 0 1];

% Find rotation matrix from referencial 0 to 6
R_0_6 = Rz*Ry*Rx;

% Find position of referencial 6
x_6 = x-(22*R_0_6(1,3));
y_6 = y-(22*R_0_6(2,3));
z_6 = z-(22*R_0_6(3,3));

% Construct link tranformation matrix from base to tool
Tbase_tool = [R_0_6(1,1) R_0_6(1,2) R_0_6(1,3) x_6; R_0_6(2,1) R_0_6(2,2) R_0_6(2,3) y_6; R_0_6(3,1) R_0_6(3,2) R_0_6(3,3) z_6; 0 0 0 1]; 

% Find teta 1
teta1(1) = atan2(y_6,x_6);
teta1(2) = atan2(-y_6,-x_6);

for i=1:2
    
    teta1_f(i,1) = teta1(i);
    
end

% Find teta 2

j=1;

for r=1:length(teta1_f)
    
    h=1;
    % Constant values
    a = cos(teta1_f(r,1))*x_6+sin(teta1_f(r,1))*y_6;
    b = z_6-99;
    c = a-29;
       
       %1st solution for teta2+3
        c23_sol1 =  (5600*b + 39200*c + b*c^2 + 7*b^2*c + b^3 + 7*c^3 - 7000*b*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2) + 1000*c*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2))/(2000*(b^2 + c^2));
        s23_sol1 =  -(b^2 + c^2 - (b*(5600*b + 39200*c + b*c^2 + 7*b^2*c + b^3 + 7*c^3 - 7000*b*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2) + 1000*c*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2)))/(50*(b^2 + c^2)) - (7*c*(5600*b + 39200*c + b*c^2 + 7*b^2*c + b^3 + 7*c^3 - 7000*b*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2) + 1000*c*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2)))/(50*(b^2 + c^2)) + 5600)/(280*b - 40*c);
       %2nd solution for teta2+3
        c23_sol2 =  (5600*b + 39200*c + b*c^2 + 7*b^2*c + b^3 + 7*c^3 + 7000*b*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2) - 1000*c*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2))/(2000*(b^2 + c^2));
        s23_sol2 =  -(b^2 + c^2 - (b*(5600*b + 39200*c + b*c^2 + 7*b^2*c + b^3 + 7*c^3 + 7000*b*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2) - 1000*c*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2)))/(50*(b^2 + c^2)) - (7*c*(5600*b + 39200*c + b*c^2 + 7*b^2*c + b^3 + 7*c^3 + 7000*b*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2) - 1000*c*(- b^4/1000000 - (b^2*c^2)/500000 + (43*b^2)/625 - c^4/1000000 + (43*c^2)/625 - 784/25)^(1/2)))/(50*(b^2 + c^2)) + 5600)/(280*b - 40*c);
       
        
        flag=0;
        if ~(isreal(c23_sol1) && isreal(s23_sol1))
            disp('ERROR: 1st solution for teta2+3 gives either non real cossine or a non real sine');
            flag=flag+1;
            continue;
        else
            
            % Find sine and cosine for first solution of teta2
            s2_sol1 = (c-140*c23_sol1-20*s23_sol1)/120;
            c2_sol1 = (b+140*s23_sol1-20*c23_sol1)/120;
            
             % Check if sin and cos are good
            if (s23_sol1 <= 1 && s23_sol1 >=-1)

                % Check if sin is good
                if (s2_sol1 <= 1 && s2_sol1 >=-1)

                    % Check if cos is good
                    if (c2_sol1 <= 1 && c2_sol1 >=-1)

                        % Find teta2
                        teta2(h)= atan2(s2_sol1,c2_sol1);

                        % Find teta3
                        teta3(h) = atan2(s23_sol1,c23_sol1)-teta2(h);

                                    
                        % Put values of teta 1, 2 and 3
                        teta2_f(r,h)= teta2(h);
                        teta3_f(r,h)= teta3(h);
                        solutions_3joints(j,:) = [teta1_f(r,1) teta2_f(r,h) teta3_f(r,h)];
                        j=j+1;
                                    
                    end

                end
            end
        
        end
        
        % Error if sine and cosine are imaginary
        if ~(isreal(c23_sol2) && isreal(s23_sol2))
            disp('ERROR: 2nd solution for teta2+3 gives either non real cossine or a non real sine');
            flag=flag+1;
            continue;
        else
            
            % Find sine and cosine for second solution of teta2
             s2_sol2 = (c-140*c23_sol2-20*s23_sol2)/120;
             c2_sol2 = (b+140*s23_sol2-20*c23_sol2)/120;
             
             % Check if sin and cos are good
            if (s23_sol2 <= 1 && s23_sol2 >=-1)

                % Check if sin is good
                if (s2_sol2 <= 1 && s2_sol2 >=-1)

                    % Check if cos is good
                    if (c2_sol2 <= 1 && c2_sol2 >=-1)

                        % Find teta2 
                        teta2(h)= atan2(s2_sol2,c2_sol2);
                             
                        % Find teta3
                        teta3(h) = atan2(s23_sol2,c23_sol2)-teta2(h);

                        % Put values of teta 1, 2 and 3
                        teta2_f(r,h)= teta2(h);
                        teta3_f(r,h)= teta3(h);
                        solutions_3joints(j,:) = [teta1_f(r,1) teta2_f(r,h) teta3_f(r,h)];
                        j=j+1;
                                     
                    end

                end
            end
        end
       
end 

j=1;
% Number of solutions so far
[row , col] = size(solutions_3joints);

if ( col ~= 1)
    for k=1:row

        % Values of teta1, teta2, and teta3 for solutions find so far
        teta1 = solutions_3joints(k,1);
        teta2 = solutions_3joints(k,2);
        teta3 = solutions_3joints(k,3);
        
        % Link transformation matrixes for teta1 teta2 and teta3
        T_0_1 = [ cos(teta1), -sin(teta1), 0, 0; sin(teta1), cos(teta1), 0, 0; 0, 0, 1, 99; 0, 0, 0, 1];
        T_1_2 = [ sin(teta2) cos(teta2) 0 29; 0 0 1 0; cos(teta2) -sin(teta2)  0 0; 0 0 0 1];
        T_2_3 = [ cos(teta3) -sin(teta3) 0 120; sin(teta3) cos(teta3) 0 0; 0 0 1 0; 0 0 0 1];
        
        % Matrix to calculate teta5
        T = inv(T_2_3)* inv(T_1_2)*inv(T_0_1)* Tbase_tool;

        % Find teta4 
        
        % Cosine of teta4 
        c4_sol1 = -T(1,3);
        c4_sol2 = T(1,3);
        
        % Sine of teta4
        s4_sol1 = T(3,3);
        s4_sol2 = -T(3,3);
        
        % Find teta4 solution 1

        % Check if values for sin and cos of teta4 are good
        if (c4_sol1 > 1 || c4_sol1 <-1)

            disp('ERROR: Cos of teta4 is a invalid number!');
            continue;
        end
        
        if (s4_sol1 > 1 || s4_sol1 < -1)
                        
            disp('ERROR: Sin of teta4 is a invalid number!');
            continue;
        end

        teta4 = atan2(s4_sol1,c4_sol1);
        
        % Transformation link from ref 3 to ref 4
        T_3_4 = [ cos(teta4) -sin(teta4) 0 20; 0 0 1 140; -sin(teta4) -cos(teta4) 0 0; 0 0 0 1];
            
        % Matrix to calculate teta5
        T = inv(T_3_4)*inv(T_2_3)* inv(T_1_2)*inv(T_0_1)* Tbase_tool;
        
            % Find teta5 solution 1
            % Cosine of teta5 
            c5 = T(3,3);

            % Sine of teta5
            s5 = -T(1,3);

            % Check if values for sin and cos of teta5 are good
            if (c5 > 1 || c5 <-1)

                disp('ERROR: Cos of teta5 is a invalid number!');
                continue;
            end

            if (s5 > 1 || s5 < -1)

                disp('ERROR: Sin of teta5 is a invalid number!');
                continue;
            end
            
            teta5 = atan2(s5,c5);
                
            if (abs(teta5) <= (0.01))
                    
                 % Value for teta4
                 teta4 = 0;

                 % Value for teta6
                 teta6 = 0;

                 % Final solutions is singularity
                 teta_f(j,:) = [round(solutions_3joints(k,1)*180/pi) round(solutions_3joints(k,2)*180/pi) round(solutions_3joints(k,3)*180/pi) round(180*teta4/pi) round(180*teta5/pi) round(180*teta6/pi)];

                 disp('Teta5 = 0 so there is a singularity!! Some possible solutions are presented in teta_f');
                 j=j+1;
                 continue;
            else
                
                    % Find teta6 solution 1
                    % Cosine of teta6 
                    c6 = T(2,2);

                    % Sine of teta6
                    s6 = T(2,1);

                    % Check if values for sin and cos of teta6 are good
                    if (c6 > 1 || c6 <-1)

                        disp('ERROR: Cos of teta6 is a invalid number!');
                        continue;
                    end

                    if (s6 > 1 || s6 < -1)

                        disp('ERROR: Sin of teta6 is a invalid number!');
                        continue;
                    end

                    % Find teta6
                    teta6 = atan2(s6,c6);
                    
                    % Final solution
                    teta_f(j,:) = [round(solutions_3joints(k,1)*180/pi) round(solutions_3joints(k,2)*180/pi) round(solutions_3joints(k,3)*180/pi) round(180*teta4/pi) round(180*teta5/pi) round(180*teta6/pi)];
                    j=j+1;

             end
        
        % Find teta4 solution 2       

        % Check if values for sin and cos of teta4 are good
        if (c4_sol2 > 1 || c4_sol2 <-1)

            disp('ERROR: Cos of teta4 is a invalid number!');
            continue;
        end
        
        if (s4_sol2 > 1 || s4_sol2 < -1)
                        
            disp('ERROR: Sin of teta4 is a invalid number!');
            continue;
        end

        teta4 = atan2(s4_sol2,c4_sol2);
        
            % Find teta5 solution 2
            % Cosine of teta5 
            c5 = T(3,3);

            % Sine of teta5
            s5 = T(1,3);

            % Check if values for sin and cos of teta5 are good
            if (c5 > 1 || c5 <-1)

                disp('ERROR: Cos of teta5 is a invalid number!');
                continue;
            end

            if (s5 > 1 || s5 < -1)

                disp('ERROR: Sin of teta5 is a invalid number!');
                continue;
            end
            
            teta5 = atan2(s5,c5);
          
            if (abs(teta5) <= (0.01))
                    
                % Value for teta4
                teta4 = 0;

                % Value for teta6
                teta6 = 0;
                
                % Final solutions is singularity
                teta_f(j,:) = [round(solutions_3joints(k,1)*180/pi) round(solutions_3joints(k,2)*180/pi) round(solutions_3joints(k,3)*180/pi) round(180*teta4/pi) round(180*teta5/pi) round(180*teta6/pi)];

                disp('Teta5 = 0 so there is a singularity!! Some possible solutions are presented in teta_f');
                j=j+1;
                continue;
            else
                    % Find teta6 solution 2
                    % Cosine of teta6 
                    c6 = -T(2,2);

                    % Sine of teta6
                    s6 = -T(2,1);

                    % Check if values for sin and cos of teta6 are good
                    if (c6 > 1 || c6 <-1)

                        disp('ERROR: Cos of teta6 is a invalid number!');
                        continue;
                    end

                    if (s6 > 1 || s6 < -1)

                        disp('ERROR: Sin of teta6 is a invalid number!');
                        continue;
                    end
                    
                    % Find teta6
                    teta6 = atan2(s6,c6);

                    % Final solution
                    teta_f(j,:) = [round(solutions_3joints(k,1)*180/pi) round(solutions_3joints(k,2)*180/pi) round(solutions_3joints(k,3)*180/pi) round(180*teta4/pi) round(180*teta5/pi) round(180*teta6/pi)];
                    j=j+1;

             end 
        
    end
   
    if ( j == 1)
    
        teta_f = 0;
        disp('ERROR: No angles are possible, so there are no solutions. Those inputs are not possible!');
    end
else
    
    teta_f = 0;
    disp('ERROR: No angles are possible, so there are no solutions. Those inputs are not possible!');
     
    
end
end