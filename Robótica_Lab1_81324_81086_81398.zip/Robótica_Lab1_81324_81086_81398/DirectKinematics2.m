% Function for Direct Kinematics

function [x,y,z,alfa,beta,gama] = DirectKinematics2(teta1, teta2, teta3, teta4, teta5, teta6)

    % Obtain the link transformation T01 with the value of teta1
    Trx = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Ta = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta1) -sin(teta1) 0 0; sin(teta1) cos(teta1) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 99; 0 0 0 1];
    Trans_0_1 = Trx*Ta*Trz*Td;

   
    % Obtain the link transformation T12 with the value of teta2
    Trx = [ 1 0 0 0; 0 0 1 0; 0 -1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 29; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta2-pi/2) -sin(teta2-pi/2) 0 0; sin(teta2-pi/2) cos(teta2-pi/2) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_1_2 = Trx*Ta*Trz*Td;

    %Obtain the link transformation T23 with the value of teta3
    Trx = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Ta = [ 1 0 0 120; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta3) -sin(teta3) 0 0; sin(teta3) cos(teta3) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_2_3 = Trx*Ta*Trz*Td;
       
    % Obtain the link transformation T34 with the value of teta4
    Trx = [ 1 0 0 0; 0 0 1 0; 0 -1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 20; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta4) -sin(teta4) 0 0; sin(teta4) cos(teta4) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 140; 0 0 0 1];
    Trans_3_4 = Trx*Ta*Trz*Td;
  
    
    % Obtain the link transformation T45 with the value of teta5
    Trx = [ 1 0 0 0; 0 0 -1 0; 0 1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta5) -sin(teta5) 0 0; sin(teta5) cos(teta5) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_4_5 = Trx*Ta*Trz*Td;
    
    % Obtain the link transformation T56 with the value of teta6
    Trx = [ 1 0 0 0; 0 0 1 0; 0 -1 0 0; 0 0 0 1];
    Ta = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trz = [ cos(teta6) -sin(teta6) 0 0; sin(teta6) cos(teta6) 0 0; 0 0 1 0; 0 0 0 1];
    Td = [ 1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];
    Trans_5_6 = Trx*Ta*Trz*Td;

    % Transformation link from referencial 0 to 6
    T_0_6 = Trans_0_1*Trans_1_2*Trans_2_3*Trans_3_4*Trans_4_5*Trans_5_6;

    % Point of end-efector at referencial 6
    P6 = [0; 0; 22; 1];

    % Point of end-efector at referencial 0
    P0 = T_0_6*P6;
    x = round(P0(1,1));
    y = round(P0(2,1));
    z = round(P0(3,1));

    % Rotation matrix from referencial 0 to 6
    R_0_6 = T_0_6(1:3 , 1:3);

    % Orientation of end-efector
    cos_beta = sqrt((R_0_6(1,1)^2)+(R_0_6(2,1)^2));

    beta = atan2(-R_0_6(3,1) , cos_beta);
    alfa = atan2( R_0_6(2,1)/cos_beta , R_0_6(1,1)/cos_beta);
    gama = atan2( R_0_6(3,2)/cos_beta , R_0_6(3,3)/cos_beta);

end
