
function [solt2, solt3, solt4] = singularities()

%Defining teta1, ... ,teta6 as symbolic variables
    syms t1 t2 t3 t4 t5 t6

    %Find link transformation from joint 0 to 1
    T01 =  [cos(t1) -sin(t1) 0 0; sin(t1) cos(t1) 0 0; 0 0 1 99; 0 0 0 1];

    %Find link transformation from joint 1 to 2
    T12 = [sin(t2) cos(t2) 0 29; 0 0 1 0; cos(t2) -sin(t2) 0 0; 0 0 0 1];

    %Find link transformation from joint 2 to 3
    T23 = [cos(t3) -sin(t3) 0 120; sin(t3) cos(t3) 0 0 ; 0 0 1 0 ; 0 0 0 1];

    %Find link transformation from joint 3 to 4
    T34 = [cos(t4) -sin(t4) 0 20; 0 0 1 140; -sin(t4) -cos(t4) 0 0; 0 0 0 1];

    %Find link transformation from joint 4 to 5
    T45 = [cos(t5) -sin(t5) 0 0; 0 0 -1 0; sin(t5) cos(t5) 0 0; 0 0 0 1];

    %Find link transformation from joint 5 to 6
    T56 = [cos(t6) -sin(t6) 0 0; 0 0 1 0; -sin(t6) -cos(t6) 0 0; 0 0 0 1];

    T2 = T01 * T12;
    T3= T01 * T12 * T23;
    T4= T01 * T12 * T23 * T34;
    T5= T01 * T12 * T23 * T34 * T45;
    
    %Find transformation matrix from referencial 0 to 6
    T06 = T01 * T12 * T23 * T34 * T45 * T56;
    
    %Creating zi
    z0= [0;0;1];
    z1= T01(1:3,3);
    z2= T2(1:3,3);
    z3= T3(1:3,3);
    z4= T4(1:3,3);
    z5= T5(1:3,3);
    
    %Obtain the translation of the homogenous transformation from reference
    %0 to reference 6
    X = [T06(1,4); T06(2,4); T06(3,4)];
    
    % Jacobian matrix Computation
    J = [diff(X, t1) diff(X, t2) diff(X, t3) diff(X, t4) diff(X, t5) diff(X, t6); z0 z1 z2 z3 z4 z5];
    J = simplify(J);
    
    
    % (3*3) blocks Jacobians
    J11=J(1:3,1:3);
    J22=J(4:6,4:6);
    
    % Determinant Calculation
    det11=simplify(det(J11));
    det22=simplify(det(J22));
    
    
    %Arm singularities: det(J11)=0 
    %NOTE: J11 only depends on teta2 and teta3
  
     %equation to solve, we added 3 more equations because we have 4
     %unknowns: sin(t2), cos(t2), sin(t3), cos(t3)
     eq = [det11 == 0, sin(t2)^2+(cos(t2))^2 == 1, (sin(t3))^2 +(cos(t3))^2 == 1, (cos(t2)*cos(t3)-sin(t2)*sin(t3))^2+(cos(t2)*sin(t3)+cos(t3)*sin(t2))^2 == 1];

     %variables to solve for
     vars = [t2 t3];
     [solt2, solt3] = solve(eq, vars);
    
    %Wrist singularities: det(J22)=0
    %NOTE: J22 only depends on teta4

     %equation to solve
     eq =  det22 == 0;

     %variables to solve for
     vars = t4;
     [solt4] = solve(eq, vars);
     

end
 