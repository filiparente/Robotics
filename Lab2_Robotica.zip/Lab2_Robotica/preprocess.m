function [trajectory_x, trajectory_y] = preprocess(trajectory_x, trajectory_y)
    %put less interpolation points in the first straight line of the
    %corridor
    
    idx1 = 41;
    idx2 = 51;
    
    point1_x = trajectory_x(idx1);
    point1_y = trajectory_y(idx1);

    point2_x = trajectory_x(idx2);
    point2_y = trajectory_y(idx2);
    
    [aux_trajectory_x, aux_trajectory_y] = find_trajectory([point1_y point2_y], [point1_x point2_x], 0.5, 2);
    
    trajectory_x = [trajectory_x(1:idx1-1) aux_trajectory_x trajectory_x(idx2+1:end)];
    trajectory_y = [trajectory_y(1:idx1-1) aux_trajectory_y trajectory_y(idx2+1:end)];


end