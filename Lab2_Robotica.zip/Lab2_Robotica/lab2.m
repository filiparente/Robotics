%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Script for tracking trajectory of a path for a mobile robot (Pioneer 3)
%
% Afonso Soares, n� 81086
% Maria Roque, n� 81398
% Filipa Rente, n� 81324
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;
delete(timerfindall);

% Initialize robot
SP = serial_port_start('COM3');
pioneer_init(SP);

% Trajectory
isFinal = 0;

% Set time
tic;
timerVal = tic;

% First half of the trajectory
figure
y1= [0 0 2 3.50 4.1 4.1 5.4 17];
x1 = [0  1 2.4 2.4 3.1 15.4 16.6 16.6]; 
[trajectory_x1, trajectory_y1] = find_trajectory(y1,x1, 0.1, 1);
plot(trajectory_x1, trajectory_y1)
hold on

% Second half of the trajectory
y2= [0 0 2 3.50 16 18.3 18.3 17];
x2 = [0 1 2.4 2.4 2.4 3.4 15.4 16.6];
[trajectory_x2, trajectory_y2] = find_trajectory(y2,x2, 0.1, 1);
plot(trajectory_x2, trajectory_y2)

% Final trajectory for y and x
trajectory_x = cat(2,trajectory_x1,fliplr(trajectory_x2));
trajectory_y = cat(2,trajectory_y1,fliplr(trajectory_y2));
trajectory_x_copy = trajectory_x;
trajectory_y_copy = trajectory_y;
[trajectory_x, trajectory_y] = preprocess(trajectory_x, trajectory_y);


trajectory_x_init = trajectory_x;
trajectory_y_init = trajectory_y;

trajectory_x = trajectory_x*1000;
trajectory_y = trajectory_y*1000;

% Control parameters
vmax = 250;
K1 = 0.6; 
K2 = 0.25;
K3 = 0.35;

threshold_y = 0;
threshold_x = 0;


% Initialization of parameters
t(1) = 0;
yref(1) = 0; 
xref(1) = 0;
i = 2;
yref(i) = trajectory_y(i); 
xref(i) = trajectory_x(i);
n_sonars = 8;
m = 1;
V(m) = vmax;
e(m) = 10000;
stop = 0;
path = 1;
no_corridor = 0;
W_thres = 0;

while (isFinal ~= 1) 
   
   % Second half of the trajectory has symetric thresholds
   if ( i > 74 )
       path = -1;
   end
    
   if (stop == 0) 
       %actualize new reference points with the trajectory
       if ( e(m) < 200 && i < (length(trajectory_x))  )
            i=i+1; 
            xref(i) = trajectory_x(i);
            yref(i) = trajectory_y(i);
            thresx_e = 1;
            thresy_e = 1;
            thresy_d = 1;
            thresx_d = 1;
            W_thres = 0;
       end
       
   
   end
   
   % Read values from the sonars
   sonars = read_sonars();
   
   % Store values from the sonars
   sonars_test(m,:) = sonars;
   
   % Read values from the odometry
   odometry = pioneer_read_odometry();
   x = odometry(1);
   y = odometry(2);
   
   % Store values from the odometry
   odometrytest(m,:) = pioneer_read_odometry();
   
   % Construct a plot with the trajectory of the robot
   if ( path == 1)
   
        scatter(x/1000,y/1000,'r') %1st half in red
        drawnow
   else
      
        scatter(x/1000,y/1000,'y') %2nd half in yellow
        drawnow
   end
  
    % Robot is in the corridor
    if ( (i > 40) && ( i < 115) )
        
     % Obstacle in front so stop   
     if( (sonars(3) < 450) || (sonars(4) < 450) || (sonars(5) < 450) || (sonars(6) < 450) ) 
         
        pioneer_set_controls(SP, 0, 0);
        stop = 1;  
        e(m+1) = 10000;
        W(m) = 0;
        V(m) = 0;
     else
         stop = 0;
         V(m) = vmax;
         if ( (W(m-1)-W_thres == 0) )% Robot is in the corridor so he can use sonars
         
             if((sonars(8) >= 550 && sonars(8) <= 900) )  %too far apart from the right side wall, move a little to the right
                 vmax = 250;
                 V(m) = vmax;
                 W_thres = 0;
             end
             
             if((sonars(8) > 900 && sonars(8) < 2000) )  %too far apart from the right side wall, move a little to the right
                 if (trajectory_y(i-1) ~= trajectory_y(i) && thresx_d == 1) %vertical path
                     
                  
                   threshold_x = (path)*40;
                   trajectory_x = trajectory_x + threshold_x;

                   xref(i) = trajectory_x(i);
                   thresy_d = 0;
                   W_thres = -5;
                   vmax = 250;
                   V(m) = vmax;
                   
                 end
               
               if (trajectory_x(i-1) ~= trajectory_x(i) && thresy_d == 1) %horizontal path
                  
                   threshold_y = - (path)*40;
                   trajectory_y = trajectory_y + threshold_y;

                   yref(i) = trajectory_y(i);
                   thresx_d = 0;
                   W_thres= -5;
                   vmax = 250;
                   V(m) = vmax;
                   
               end
             elseif(sonars(8) < 550 || sonars(7) < 550) %too close to the right side wall, move a little to the left
                   if (trajectory_y(i-1) ~= trajectory_y(i) && thresx_e == 1) %vertical path
                  
                       threshold_x = - (path)*40;
                       trajectory_x = trajectory_x + threshold_x;
                      
                       xref(i) = trajectory_x(i);
                       thresy_e = 0;
                       W_thres = 5;
                       vmax = 250;
                       V(m) = vmax;
                       
                   end
                   
                   
                   if (trajectory_x(i-1) ~= trajectory_x(i) && thresy_e == 1) %horizontal path

                        threshold_y = (path)*40;
                        trajectory_y = trajectory_y + threshold_y;

                        yref(i) = trajectory_y(i);
                        thresx_e = 0;
                        W_thres = 5;
                        vmax = 250;
                        V(m) = vmax;
                        
                   end
                   
             end
         end
     end
    
    end
        
     
    if ( stop == 0)
       % Calculate value of angle of the robot in his ref
       
       if ( path == -1)
        
           teta = (odometry(3))*(2*pi)/4096;
       else    
           if (odometry(3) >= 2048)
            teta =  -(2*pi-(odometry(3)*2*pi/4096));

           else
            teta = odometry(3)*(2*pi)/4096;
           end
       end
       

       % Distance from the position of the robot to the position he wants
       % to go.
       e(m+1) = sqrt(((xref(i)-x)^2)+((yref(i)-y)^2));
       error = e(m+1);
       
%Calculate angle values for the control law

if(xref(i) == x || yref(i) == y)
     phi = teta;
     alfa=0; 
else          
      phi = atan2((yref(i)-y),(xref(i)-x));
      if ( path == -1 )
          if ( phi > 0)
              alfa = phi - teta;
          end

          if ( phi < 0)

              phi = (2*pi)+phi;
              alfa = phi-teta;
              
          end        
      else
                
         alfa = phi-teta;
      end
      
    
end
       
       % Control law
    
       % Actualize Angular velocity from the control law expression
       if(abs(alfa) < 0.05)
          W(m)=0;
          V(m) = vmax;
       else
          W(m) = round(vmax*((1+K2*(phi/alfa))*(tanh(K1*e(m))/e(m))*sin(alfa)+K3*tanh(alfa)));
          V(m) = vmax;
       end
       
       % Linear Velocity is actualized when he are reaching to the end of the trajectory 
       if ( i == length(trajectory_x)-4)
    
            V(m) = round(vmax*tanh(K1*e(m))); %se o erro for 0 isto d� 0 e o robot p�ra
            
       end
       
       
       % Send message with velocities to the robot
       pioneer_set_controls(SP, V(m), W(m)+W_thres);
  
    end
   
   % Stop! Velocity is too high
   if ( V > 400)
    
        pioneer_set_controls(SP, 0, 0);
        disp('ERROR: Invalid value for the linear velocity!');
        isFinal = 1;
       
   end
   
  
   % Robot reached to the end of the trajectory so stop!!
   if ( i == length(trajectory_x) && e(m) < 200 )
       
        pioneer_set_controls(SP, 0, 0);
        
        disp('Robot arrived to the end of the trajectory');
        isFinal = 1;
        
   end
   if( isFinal == 0)
       
        m=m+1;
        t(m) = toc;
   end
    
end

% Stop link with the robot
serial_port_stop(SP);