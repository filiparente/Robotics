
%Function to ignore peaks in the sonar's readings
function sonars_corrected = read_sonars()
    
    for i = 1:5
        sonars(i,:) = pioneer_read_sonars();
        pause(0.01); % 0.01 seconds -> sampling frequency of 1/0.01 = 100 Hz
    end
    
    %Calculate the median, it's better than the average to ignore high or low peaks
    for n_sonars = 1:8
        sonars_corrected(n_sonars) = median(sonars(:,n_sonars));
    end
    

end