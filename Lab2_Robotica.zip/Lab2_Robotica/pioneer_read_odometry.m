function odometry = pioneer_read_odometry()

global pioneer_odometry;

odometry = pioneer_odometry;

end
