function n = parseuint(data)
    n = data(1) + 2^8*data(2);
return
    