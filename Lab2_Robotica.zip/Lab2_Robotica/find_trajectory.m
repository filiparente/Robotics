
% This function creates the trajectory for the robot
% y- 8 points for coordenate y
% x- 8 points for coordenate x
% step_size- minimum difference between points in the interpolation
% mode- to tips of modes for the trajectory. First mode do the normal, the
% second do the trajectory with less points
function [trajectory_x, trajectory_y] = find_trajectory(y,x, step_size, mode)
    
    if mode == 1
        t = [0 1 2 3 4 5 6 7];
        tq = 0:step_size:7;
    elseif mode == 2
        t = [0 1];
        tq = 0:step_size:1;
    end

    trajectory_x = interp1(t,x,tq,'pchip'); 
    trajectory_y = interp1(t,y,tq,'pchip');
end